README
================
2024-06-03

# A One Health framework for exploring zoonotic interactions demonstrated through a case study

Repository for Desvars-Larrive et al. manuscript on the comprehensive
analysis of the zoonotic web in Austria, 1975-2022. This study is a
collaboration between scientists of the Clinical Department for Farm
Animals and Food System Science at the University of Veterinary Medicine
(Vetmeduni) Vienna (Austria), the Department of Biological Sciences and
Pathobiology at the Vetmeduni Vienna, and the Complexity Science Hub
Vienna (Austria). <br>

This repository contains the R code to clean and validate the data
collected from scientific publications and the final table resulting
from these processes. It also contains the R code used to analyse this
data. <br>

**<code>DataValidationCleaning.R</code>**: R code for cleaning and
validating the raw data. <br>

**<code>AnalysisZoonoticWeb.R</code>**: R code for analysing the final
dataset and produce the figures.<br>

**<code>data_zoonoses_austria4.csv</code>**: Raw data that were
extracted from the information sources.<br>

**<code>inferred_hosts.csv</code>**: Most specific terminology for host
names that can be extracted from the information sources. Used for
cleaning and validation processes.<br>

**<code>table_final.csv</code>**: Cleaned dataset. <br>

**<code>categories_food.csv</code>**: Categories of food used in the
analysis. <br>

**<code>PubMed_Timeline_Results_by_Year.csv</code>**: Results of the
PubMed search using the terms (zoono\* OR “zoono\* disease\*“) from 1975
until 23 August 2022. <br>

**<code>PubMed_Timeline_Results_by_Year_Health.csv</code>**: Results of
the PubMed search using the term “health” from 1975 until 23 August
2022. <br>

## Dependencies

- Windows 10
- R Statistical Software version 4.3.0 (2023-04-21 ucrt)
- RStudio 2023.06.0+421, Release
  (583b465ecc45e60ee9de085148cd2f9741cc5214, 2023-06-05) for windows

## Installation

### For Windows

1.  Install R by downloading it from
    [CRAN](https://cran.r-project.org/bin/windows/base/).

2.  Install RStudio by downloading it from
    [RStudio](https://www.rstudio.com/products/rstudio/download/).

3.  Open RStudio and install any required R packages using the following
    commands:

    ``` r
    install.packages("dplyr")
    install.packages("ggplot2")
    install.packages("patchwork")
    install.packages("stringr")
    install.packages("ggfittext")
    install.packages("tidyr")
    install.packages("caret")
    install.packages("matrixStats")
    install.packages("plyr")
    install.packages("egg")
    install.packages("RColorBrewer")
    install.packages("igraph")
    install.packages("ggrepel")
    install.packages("ggraph")
    install.packages("bipartite")
    install.packages("tidyverse")
    install.packages("rsetse")
    install.packages("hrbrthemes")
    install.packages("lubridate")
    install.packages("forcats")
    install.packages("CINNA")
    install.packages("bc3net")
    install.packages("purrr")
    install.packages("scales")
    install.packages("ggalluvial")
    install.packages("cowplot")
    ```

- Typical install time on a “normal” desktop computer: approximately
  15-20 minutes.

## Usage

- Store data and script files in the same project folder.
- Open the analysis script in RStudio (`AnalysisZoonoticWeb.R`).
- Run the analysis.
- Figures and tables generated when running the script will be exported
  into the project folder.

## Instructions for use

The analysis script (`AnalysisZoonoticWeb.R`) is comprehensively
documented and will lead you to reproduction of results and figures.

## Expected outputs

- Quantitative results as described in the article and supplementary
  information.
- Figures and tables as they appear in the article and supplementary
  information (note that Figure 5 was not produced with R).

On a “normal” desktop computer: approximately 20 minutes.
